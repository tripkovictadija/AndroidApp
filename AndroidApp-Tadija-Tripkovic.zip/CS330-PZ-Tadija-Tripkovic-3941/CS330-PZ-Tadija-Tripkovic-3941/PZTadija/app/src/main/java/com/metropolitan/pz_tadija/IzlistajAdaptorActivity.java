package com.metropolitan.pz_tadija;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FilterQueryProvider;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;

public class IzlistajAdaptorActivity extends AppCompatActivity  {

    private ArrayList<Country> terminiArrayList;
    private CountriesDbAdapter dbHelper;
    private SimpleCursorAdapter dataAdapter;

    ListView listView;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zakazivanja);

        listView = (ListView) findViewById(R.id.listView1);

        dbHelper = new CountriesDbAdapter(this);
        dbHelper.open();
        terminiArrayList = new ArrayList<>();

        listView.setAdapter(dataAdapter);
         registerForContextMenu(listView);

        //Clean all data
       // dbHelper.deleteAllCountries();
        //Add some data
       // dbHelper.insertSomeCountries();

        //Generate ListView from SQLite Database
        displayListView();

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.zakazivanja_context, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int position = 0;
        if (item.getItemId() == R.id.obrisiZapis){
           // AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            Cursor cursor = (Cursor) listView.getItemAtPosition(position);
           int countryCode = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
            dbHelper.obrisi(countryCode);
            Toast.makeText(getApplicationContext(),
                    "Zapis je uspešno obrisan.", Toast.LENGTH_SHORT).show();
            displayListView();
//            Country termin = terminiArrayList.get(menuInfo.position);
//            terminiArrayList.remove(menuInfo.position);
//            dataAdapter.notifyDataSetChanged();
            return true;
        }else if (item.getItemId() == R.id.izmeniZapis){
            Cursor cursor = (Cursor) listView.getItemAtPosition(position);
            Integer countryCode = cursor.getInt(cursor.getColumnIndexOrThrow("_id"));
           // dbHandler.izmeni(1, "10-10-2022");
//            String cc2 = Integer.toString(countryCode);
//            Toast.makeText(getApplicationContext(),
//                    cc2, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, Izmena.class);
            i.putExtra("counterID", countryCode);
            startActivity(i);
        }
        return false;
    }


    private void displayListView() {


        Cursor cursor = dbHelper.fetchAllCountries();

        // The desired columns to be bound
        String[] columns = new String[] {
                CountriesDbAdapter.KEY_DOKTOR,
                CountriesDbAdapter.KEY_IMEPAC,
                CountriesDbAdapter.KEY_PREZIMEPAC,
                CountriesDbAdapter.KEY_INTERVENCIJA,
                CountriesDbAdapter.KEY_TELEFON,
                CountriesDbAdapter.KEY_DATUM,
                CountriesDbAdapter.KEY_VREME
        };

        // the XML defined views which the data will be bound to
        int[] to = new int[] {
                R.id.doktor,
                R.id.imePacijenta,
                R.id.prezimePacijenta,
                R.id.intervencija,
                R.id.telefon,
                R.id.datum,
                R.id.vreme
        };

        // create the adapter using the cursor pointing to the desired data
        //as well as the layout information
        dataAdapter = new SimpleCursorAdapter(
                this, R.layout.country_info,
                cursor,
                columns,
                to,
                0);

        ListView listView = (ListView) findViewById(R.id.listView1);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);


        listView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> listView, View view,
                                    int position, long id) {
                // Get the cursor, positioned to the corresponding row in the result set
                Cursor cursor = (Cursor) listView.getItemAtPosition(position);

                // Get the state's capital from this row in the database.
                String countryCode =
                        cursor.getString(cursor.getColumnIndexOrThrow("_id"));
                Toast.makeText(getApplicationContext(),
                        countryCode, Toast.LENGTH_SHORT).show();

            }
        });

        EditText myFilter = (EditText) findViewById(R.id.myFilter);
        myFilter.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                dataAdapter.getFilter().filter(s.toString());
            }
        });

        dataAdapter.setFilterQueryProvider(new FilterQueryProvider() {
            public Cursor runQuery(CharSequence constraint) {
                return dbHelper.fetchCountriesByName(constraint.toString());
            }
        });

    }
}