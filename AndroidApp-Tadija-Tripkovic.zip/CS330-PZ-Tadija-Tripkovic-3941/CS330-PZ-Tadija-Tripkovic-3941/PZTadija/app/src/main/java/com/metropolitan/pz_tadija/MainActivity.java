package com.metropolitan.pz_tadija;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickONamaPage(View view) {
        Intent i1 = new Intent(this, O_nama.class);
        startActivity(i1);
    }

    public void onClickZakazivanjePage(View view) {
        Intent i2 = new Intent(this, IzlistajAdaptorActivity.class);
        startActivity(i2);
    }

    public void onClickDodavanjePage(View view) {
        Intent i3 = new Intent(this, Dodavanje.class);
        startActivity(i3);
    }

    public void onClickLokacijaPage(View view) {
        Intent i4 = new Intent(this, Lokacija.class);
        startActivity(i4);
    }

    public void onClickMailPage(View view) {
        Intent i5 = new Intent(this, SendEmail.class);
        startActivity(i5);
    }
}