package com.metropolitan.pz_tadija;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class CountriesDbAdapter {

    public static final String KEY_ROWID = "_id";
    public static final String KEY_DOKTOR = "doktor";
    public static final String KEY_IMEPAC = "ime_pacijenta";
    public static final String KEY_PREZIMEPAC = "prezime_pacijenta";
    public static final String KEY_INTERVENCIJA = "intervencija";
    public static final String KEY_TELEFON = "telefon";
    public static final String KEY_DATUM = "datum";
    public static final String KEY_VREME = "vreme";

    private static final String TAG = "TerminiDbAdapter";
    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String DATABASE_NAME = "ordinacija";
    private static final String SQLITE_TABLE = "zakazivanje";
    private static final int DATABASE_VERSION = 1;

    private final Context mCtx;

    private static final String DATABASE_CREATE =
            "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
                    KEY_ROWID + " integer PRIMARY KEY autoincrement," +
                    KEY_DOKTOR + "," +
                    KEY_IMEPAC + "," +
                    KEY_PREZIMEPAC + "," +
                    KEY_INTERVENCIJA + "," +
                    KEY_TELEFON + "," +
                    KEY_DATUM + "," +
                    KEY_VREME +");";

    private static class DatabaseHelper extends SQLiteOpenHelper {

        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
           SQLiteDatabase mDb = this.getWritableDatabase();
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.w(TAG, DATABASE_CREATE);
            db.execSQL(DATABASE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + SQLITE_TABLE);
            onCreate(db);
        }
    }

    public CountriesDbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    public CountriesDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (mDbHelper != null) {
            mDbHelper.close();
        }
    }

    public void createCountry(String doktor, String imePac,
                              String prezimePac, String intervencija, String telefon, String datum,
                              String vreme) {

        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();

        ContentValues initialValues = new ContentValues();

        initialValues.put(KEY_DOKTOR, doktor);
        initialValues.put(KEY_IMEPAC, imePac);
        initialValues.put(KEY_PREZIMEPAC, prezimePac);
        initialValues.put(KEY_INTERVENCIJA, intervencija);
        initialValues.put(KEY_TELEFON, telefon);
        initialValues.put(KEY_DATUM, datum);
        initialValues.put(KEY_VREME, vreme);

        mDb.insert(SQLITE_TABLE, null, initialValues);
        mDb.close();
    }

//    public boolean deleteAllCountries() {
//
//        int doneDelete = 0;
//        doneDelete = mDb.delete(SQLITE_TABLE, null , null);
//        Log.w(TAG, Integer.toString(doneDelete));
//        return doneDelete > 0;
//
//    }

    public void obrisi(int id){

        String query = "DELETE FROM " + SQLITE_TABLE + " WHERE _id = " + id +";";
        mDb.execSQL(query);
    }

    public void izmeni(int id, String doktor, String imePac,
                       String prezimePac, String intervencija, String telefon, String datum,
                       String vreme){

        String query = "UPDATE " + SQLITE_TABLE + " SET doktor = '" + doktor + "', ime_pacijenta = '" +imePac + "', prezime_pacijenta = '" + prezimePac + "', intervencija = '" + intervencija + "', telefon = '" + telefon + "', datum = '" + datum + "', vreme = '" + vreme +"' WHERE _id = " + id +";";
        mDb.execSQL(query);
    }

    public Cursor fetchCountriesByName(String inputText) throws SQLException {
        Log.w(TAG, inputText);
        Cursor mCursor = null;
        if (inputText == null  ||  inputText.length () == 0)  {
            mCursor = mDb.query(SQLITE_TABLE, new String[] {KEY_ROWID,
                            KEY_DOKTOR, KEY_IMEPAC, KEY_PREZIMEPAC, KEY_INTERVENCIJA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                    null, null, null, null, null);

        }
        else {
            mCursor = mDb.query(true, SQLITE_TABLE, new String[] {KEY_ROWID,
                            KEY_DOKTOR, KEY_IMEPAC, KEY_PREZIMEPAC, KEY_INTERVENCIJA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                    KEY_IMEPAC  + " like '%" + inputText + "%'", null,
                    null, null, null, null);
        }
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchAllCountries() {

        Cursor mCursor = mDb.query(SQLITE_TABLE, new String[] {KEY_ROWID,
                        KEY_DOKTOR, KEY_IMEPAC, KEY_PREZIMEPAC, KEY_INTERVENCIJA, KEY_TELEFON, KEY_DATUM, KEY_VREME},
                null, null, null, null, null);

        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

//    public void insertSomeCountries() {
//
//        createCountry("Dr Tadija Tripkovic","Nikola","Nikic","Popravka zuba", "0624457465", "10.08.2022.", "14:00");
//        createCountry("Dr Mina Matic","Andjelo","Ankic","Popravka zuba", "0624457465", "10.08.2022.", "14:00");
//        createCountry("Dr Micke Antic","Nikola","Peric","Skidanje kamenca", "0624457465", "10.08.2022.", "14:00");
//        createCountry("Dr Tadija Tripkovic","Teodora","Soc","Popravka sestice", "0624457465", "10.08.2022.", "14:00");
//
//
//    }

}