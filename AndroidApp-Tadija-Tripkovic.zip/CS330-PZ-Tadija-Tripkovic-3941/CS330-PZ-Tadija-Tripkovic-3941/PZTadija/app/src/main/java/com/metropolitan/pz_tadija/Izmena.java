package com.metropolitan.pz_tadija;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class Izmena extends AppCompatActivity {

    int y, m, d, h, min;
    EditText txtDatumIzmena, txtVremeIzmena;
    CountriesDbAdapter dbHandler;
    EditText txtDoktorIzmena, txtimePacIzmena, txtprezimePacIzmena, txtIntervencijaIzmena, txtTelefonIzmena;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.izmena);

        dbHandler = new CountriesDbAdapter(this);
        dbHandler.open();

        txtDatumIzmena = findViewById(R.id.txtDatumIzmena);
        txtVremeIzmena = findViewById(R.id.txtVremeIzmena);
        txtDoktorIzmena = findViewById(R.id.txtDoktorIzmena);
        txtimePacIzmena = findViewById(R.id.txtImePacIzmena);
        txtprezimePacIzmena = findViewById(R.id.txtPrezimePacIzmena);
        txtIntervencijaIzmena = findViewById(R.id.txtIntervencijaIzmena);
        txtTelefonIzmena = findViewById(R.id.txtTelefonIzmena);
    }

    public void biranjeDatuma(View view) {

        final Calendar c = Calendar.getInstance();
        y = c.get(Calendar.YEAR);
        m = c.get(Calendar.MONTH);
        d = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view1, year, monthOfYear, dayOfMonth) -> txtDatumIzmena.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year), y, m, d);
        datePickerDialog.show();
    }

    public void biranjeVremena(View view) {

        final Calendar c = Calendar.getInstance();
        h = c.get(Calendar.HOUR_OF_DAY);
        min = c.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view1, hourOfDay, minute) -> txtVremeIzmena.setText(hourOfDay + ":" + minute), h, min, false);
        timePickerDialog.show();
    }

    public void onClickIzmena(View view){
        Bundle bundle = getIntent().getExtras();
        int counter = bundle.getInt("counterID");
        String doktor = txtDoktorIzmena.getText().toString();
        String imePac = txtimePacIzmena.getText().toString();
        String prezimePac = txtprezimePacIzmena.getText().toString();
        String interv = txtIntervencijaIzmena.getText().toString();
        String tel = txtTelefonIzmena.getText().toString();
        String datum = txtDatumIzmena.getText().toString();
        String vreme = txtVremeIzmena.getText().toString();
        dbHandler.izmeni(counter, doktor, imePac, prezimePac, interv, tel, datum, vreme);
       // String cc2 = Integer.toString(counter);
        Toast.makeText(getApplicationContext(),
                "Zapis je uspešno izmenjen.", Toast.LENGTH_SHORT).show();


        Intent i = new Intent(this, IzlistajAdaptorActivity.class);
        startActivity(i);

    }
}
