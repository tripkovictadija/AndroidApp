package com.metropolitan.pz_tadija;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Lokacija extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lokacija);

        WebView webView = findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.loadUrl("https://www.google.com/maps/place/Dental+Damnjanovi%C4%87/@43.6258751,21.1291655,17z/data=!3m1!4b1!4m5!3m4!1s0x47568ab5ff098451:0xe757ecb7916d3fe8!8m2!3d43.6258751!4d21.1313542");
    }
}
