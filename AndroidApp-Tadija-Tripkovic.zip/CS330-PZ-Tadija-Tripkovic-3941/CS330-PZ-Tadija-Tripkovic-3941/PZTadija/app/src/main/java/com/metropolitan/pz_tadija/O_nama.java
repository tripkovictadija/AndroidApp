package com.metropolitan.pz_tadija;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import androidx.appcompat.app.AppCompatActivity;

public class O_nama extends AppCompatActivity{

ImageButton btnPrevious, btnNext;
ImageSwitcher imgSwitcher;
int imageList[] = {R.drawable.ord1, R.drawable.ord2, R.drawable.ord3, R.drawable.ord4};
int count = imageList.length;
int currentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onama);

        btnPrevious = findViewById(R.id.btn_prev);
        btnNext = findViewById(R.id.btn_next);
        imgSwitcher = findViewById(R.id.img_switcher);

        imgSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getApplicationContext());
                imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imageView.setLayoutParams(new ImageSwitcher.LayoutParams(
                        LinearLayout.LayoutParams.FILL_PARENT,
                        LinearLayout.LayoutParams.FILL_PARENT) );
               return imageView;
            }
        });
        imgSwitcher.setImageResource(imageList[0]);

        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgSwitcher.setInAnimation(O_nama.this, R.anim.from_right);
                imgSwitcher.setOutAnimation(O_nama.this, R.anim.to_left);
                --currentIndex;
                if(currentIndex < 0)
                    currentIndex = imageList.length - 1;
                imgSwitcher.setImageResource(imageList[currentIndex]);
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgSwitcher.setInAnimation(O_nama.this, R.anim.from_left);
                imgSwitcher.setOutAnimation(O_nama.this, R.anim.to_right);
                currentIndex++;
                if(currentIndex == count)
                    currentIndex = 0;
                imgSwitcher.setImageResource(imageList[currentIndex]);
            }
        });
    }








}
