package com.metropolitan.pz_tadija;

public class Country {

    String doktor = null;
    String imePac = null;
    String prezimePac = null;
    String intervencija = null;
    String telefon = null;
    String datum = null;
    String vreme = null;

    public String getDoktor() {
        return doktor;
    }

    public void setDoktor(String doktor) {
        this.doktor = doktor;
    }

    public String getImePac() {
        return imePac;
    }

    public void setImePac(String imePac) {
        this.imePac = imePac;
    }

    public String getPrezimePac() {
        return prezimePac;
    }

    public void setPrezimePac(String prezimePac) {
        this.prezimePac = prezimePac;
    }

    public String getIntervencija() {
        return intervencija;
    }

    public void setIntervencija(String intervencija) {
        this.intervencija = intervencija;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getVreme() {
        return vreme;
    }

    public void setVreme(String vreme) {
        this.vreme = vreme;
    }
}